SELECT c1.cid AS cid1, c2.cid AS cid2
FROM Course c1,Course c2
WHERE c1.cid < c2.cid 
AND NOT EXISTS (SELECT preid 
				FROM Prerequisites p1 
				WHERE p1.cid=c1.cid AND p1.preid NOT IN (SELECT preid 
														FROM Prerequisites p2 
														WHERE p2.cid=c2.cid))
AND NOT EXISTS (SELECT preid 
				FROM Prerequisites p1 
				WHERE p1.cid=c2.cid AND p1.preid NOT IN (SELECT preid 
														FROM Prerequisites p2 
														WHERE p2.cid=c1.cid))
ORDER BY c1.cid, c2.cid;

