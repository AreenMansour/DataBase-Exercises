select institution 
from institutions 
where country='il'
order by institution;