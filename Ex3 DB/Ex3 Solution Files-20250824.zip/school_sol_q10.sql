with aiCount(name, year, totalcount) as 
(select name, year, sum(totalcount)
from authors natural join conferences
where institution='Hebrew University of Jerusalem' and area='ai'
group by name,year)
select  year,name
from aiCount
where year>=2000 and year<=2020
except
select a2.year,a2.name
from aiCount a1, aiCount a2
where a1.year=a2.year
and  a1. totalcount >a2. totalcount
order by year,name;
