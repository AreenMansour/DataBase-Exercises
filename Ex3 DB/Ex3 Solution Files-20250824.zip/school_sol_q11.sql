with OldConferences(conference) as 
(select conference
from authors
group by conference
having count(distinct year) >15)

select name
from authors

except

select name
from authors
where conference in (select * from OldConferences)
order by name;
