select distinct institution,name
from conferences natural join authors natural join institutions
where country='il' and totalcount>=2 and conference LIKE 'sig%'
order by institution,name;