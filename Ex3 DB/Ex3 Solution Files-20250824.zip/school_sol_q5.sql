select distinct name
from authors natural join conferences
where area='theory'
except
select name
from authors natural join conferences
where year>=1980 or area!='theory'
order by name; 