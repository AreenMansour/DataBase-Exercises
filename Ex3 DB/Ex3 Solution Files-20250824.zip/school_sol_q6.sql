select distinct name
from authors a1
where not exists
                (select *
                from authors a2
                where a2.name='Omri Abend' and
                (conference,year) not in(select conference,year
                               from authors a3
                               where a3.name=a1.name
                               )
                )
order by name;