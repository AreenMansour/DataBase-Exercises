select country, count(distinct institution) as institutionCount
from institutions
group by country
order by country;
