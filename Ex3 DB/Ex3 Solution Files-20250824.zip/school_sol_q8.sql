select name
from authors natural join conferences 
where subarea = 'ml'
group by name
having count(distinct conference) >= 3 and max(year) >= 2020 
order by name;
