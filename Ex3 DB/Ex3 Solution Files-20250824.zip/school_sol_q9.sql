With institutionCount(country, institution, countryCount) as (
select country, institution, sum(totalcount) as countryCount
from institutions natural join authors
group by country, institution)

select country, institution, countryCount
from institutionCount C1
where countryCount >= ALL (
select countryCount
from institutionCount C2
where C1. country = C2. country)
order by country, institution;
