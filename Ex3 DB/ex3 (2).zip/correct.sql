
WITH PrereqGroups AS (
    SELECT cid, STRING_AGG(preid::text, ',' ORDER BY preid) AS prereq_list
    FROM Prerequisites
    GROUP BY cid
)
SELECT c1.cid AS cid1, c2.cid AS cid2
FROM PrereqGroups c1
JOIN PrereqGroups c2 ON c1.cid < c2.cid
WHERE c1.prereq_list = c2.prereq_list
ORDER BY c1.cid, c2.cid;
