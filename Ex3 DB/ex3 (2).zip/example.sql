INSERT INTO Course VALUES ('1', 'Computer Science');
INSERT INTO Course VALUES ('2', 'Computer Science');
INSERT INTO Course VALUES ('3', 'Computer Science');
INSERT INTO Course VALUES ('4', 'Computer Science');
INSERT INTO Prerequisites VALUES (3, 4);
INSERT INTO Prerequisites VALUES (3, 1);
INSERT INTO Prerequisites VALUES (2, 1);
INSERT INTO Prerequisites VALUES (2, 4);