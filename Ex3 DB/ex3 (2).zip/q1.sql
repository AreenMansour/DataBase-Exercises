SELECT DISTINCT institution
FROM institutions
WHERE country = 'il'
ORDER BY institution;
